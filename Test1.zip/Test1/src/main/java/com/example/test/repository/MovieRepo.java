package com.example.test.repository;

import com.example.test.entity.Movie;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface MovieRepo extends JpaRepository<Movie, Integer>, JpaSpecificationExecutor<Movie> {

}
