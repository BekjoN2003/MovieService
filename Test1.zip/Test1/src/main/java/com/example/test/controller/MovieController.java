package com.example.test.controller;

import com.example.test.dto.movie.MovieCreateDto;
import com.example.test.dto.movie.MovieDto;
import com.example.test.dto.movie.MovieFilterDto;
import com.example.test.dto.user.UserDto;
import com.example.test.dto.user.UserFilterDto;
import com.example.test.service.MovieService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/movie")
public class MovieController {
    private final MovieService movieService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @PostMapping
    public ResponseEntity<?> createMovie(@RequestBody @Valid MovieCreateDto dto) {
        MovieDto result = movieService.create(dto);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getMovie(@PathVariable("id") Integer id) {
        MovieDto result = movieService.get(id);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/filter")
    public ResponseEntity<?> filterMovie(@RequestBody @Valid MovieFilterDto dto) {
        List<MovieDto> result = movieService.filter(dto);
        return ResponseEntity.ok(result);
    }
}
