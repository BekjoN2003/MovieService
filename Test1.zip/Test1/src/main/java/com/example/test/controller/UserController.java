package com.example.test.controller;

import com.example.test.dto.user.UserCreateDto;
import com.example.test.dto.user.UserDto;
import com.example.test.dto.user.UserFilterDto;
import com.example.test.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/user")

public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody @Valid UserCreateDto dto) {
        UserDto result = userService.create(dto);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUser(@PathVariable("id") Integer id) {
        UserDto result = userService.get(id);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/filter")
    public ResponseEntity<?> filterUser(@RequestBody @Valid UserFilterDto dto) {
        List<UserDto> result = userService.filter(dto);
        return ResponseEntity.ok(result);
    }
}
